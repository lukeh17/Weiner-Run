//
//  MPUBMoatBaseTracker.h
//  MPUBMoatMobileAppKit
//
//  Created by Moat on 7/27/16.
//  Copyright © 2016 Moat. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MPUBMoatBaseTracker : NSObject
@end
